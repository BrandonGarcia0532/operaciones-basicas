//Actividad 1 de lenguajes de programación programa que dictamina si eres o no mayor de edad 

#include <iostream>
#include <stdio.h>

int main ()
{
    int edad;
    std::cout << "Ingrese su edad:";
    std::cin >> edad;

    if (edad >= 18) {
        std::cout << "Usted es mayor de edad " << std::endl;
    }
    else {
        std::cout << "Usted No es mayor de edad " << std::endl;
    }
    return 0;

}

